const express = require('express');
const app = express();

app.use(express.static('public'));

app.get('/', function(req, res) {
  if(!req.query.cookie){
    res.sendFile(__dirname + '/views/index.html');
    return;
  }
  if(req.query.cookie.includes("'")){
    res.sendFile(__dirname + '/views/error.html');
    return;
  }
  res.sendFile(__dirname + '/views/results.html');
});

app.get('/u0tiI6DJlA1Zj9n2irnB/biscuits.txt', function(req, res){
  res.sendFile(__dirname + '/views/biscuits.txt');
});

app.get('/robots.txt', function(req, res){
  res.sendFile(__dirname + '/views/robots.txt');
});

const listener = app.listen(3000);
